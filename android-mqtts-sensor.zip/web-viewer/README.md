# Web Viewer
Open index.html and edit HiveMQ settings.
