package com.example.mqttsensor;
public class MainActivity { /* Placeholder minimal file to allow zip creation */ }
